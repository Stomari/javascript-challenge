// Rover Object Goes Here
var rover = {
  direction: "N",
  x: 0,
  y: 0,
  travelLog: []
};
//
var grid = [
  [null, null, "o", null, null, null, "o", null, null, null],
  [null, null, null, "o", null, null, null, null, "o", null],
  ["o", null, null, null, null, null, null, "o", null, null],
  [null, "o", "o", null, null, null, null, null, null, null],
  [null, null, null, null, "o", null, null, "o", null, null],
  [null, null, null, null, null, null, null, null, "o", "o"],
  [null, null, "o", null, null, null, null, "o", null, null],
  [null, "o", null, null, null, "o", null, null, null, null],
  [null, null, "o", null, "o", null, null, null, null, null],
  ["o", null, null, null, null, null, "o", null, null, null]
];
//
console.log("Rover is now facing " + rover.direction);

function turnLeft() {
  console.log("turnLeft was called!");
  switch (rover.direction) {
    case "N":
      rover.direction = "W";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "W":
      rover.direction = "S";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "S":
      rover.direction = "E";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "E":
      rover.direction = "N";
      console.log("Rover is now facing " + rover.direction);
      break;
  }
}

function turnRight() {
  console.log("turnRight was called!");
  switch (rover.direction) {
    case "N":
      rover.direction = "E";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "E":
      rover.direction = "S";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "S":
      rover.direction = "W";
      console.log("Rover is now facing " + rover.direction);
      break;
    case "W":
      rover.direction = "N";
      console.log("Rover is now facing " + rover.direction);
      break;
  }
}

function moveForward() {
  console.log("moveForward was called");
  switch (rover.direction) {
    case "N":
      rover.y -= 1;
      if (rover.y < 0) {
        rover.y += 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.y += 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "W":
      rover.x -= 1;
      if (rover.x < 0) {
        rover.x += 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.x += 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "S":
      rover.y += 1;
      if (rover.y > 10) {
        rover.y -= 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.y -= 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "E":
      rover.x += 1;
      if (rover.x > 10) {
        rover.x -= 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.x -= 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
  }
}

function moveBackward() {
  console.log("moveBackward was called");
  switch (rover.direction) {
    case "N":
      rover.y += 1;
      if (rover.y > 10) {
        rover.y -= 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.y -= 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "W":
      rover.x += 1;
      if (rover.x > 10) {
        rover.x -= 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.x -= 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "S":
      rover.y -= 1;
      if (rover.y < 0) {
        rover.y += 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.y += 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
    case "E":
      rover.x -= 1;
      if (rover.x < 0) {
        rover.x += 1;
        console.log("You can't go this way!");
      } else if (grid[rover.x][rover.y] === "o") {
        rover.x += 1;
        console.log("There's an obstacle ahead. You can't go this way!");
      }
      break;
  }
}

function commands(list) {
  var validation = true;

  for (let i = 0; i < list.length; i++) {
    var sequence = list[i];
    if (sequence === "f") {
      continue;
    } else if (sequence === "r") {
      continue;
    } else if (sequence === "l") {
      continue;
    } else if (sequence === "b") {
      continue;
    } else {
      console.log(
        sequence +
          " is not a command. Please enter only the letters f, b, r or l."
      );
      validation = false;
      return;
    }
  }

  if (validation === true) {
    for (let i = 0; i < list.length; i++) {
      var sequence = list[i];
      if (sequence === "f") {
        moveForward();
        rover.travelLog.push("[" + rover.x + "," + rover.y + "]");
      } else if (sequence === "r") {
        turnRight();
      } else if (sequence === "l") {
        turnLeft();
      } else if (sequence === "b") {
        moveBackward();
        rover.travelLog.push("[" + rover.x + "," + rover.y + "]");
      } else {
        console.log(sequence + " is not a command.");
      }
    }
  }
  console.log("You've been at " + rover.travelLog + ".");
}
